# 1. Read your dataset and target the numeric column
listdata = read.table('C:\\Users\\NYC\\Downloads\\ISBDA_20-5-2026\\omniretail_simulated_data.csv', header = TRUE, sep = ",")
numericdata <- unlist(listdata$Processing_Time)
# 2. Automate Sturges' Rule calculations
n = length(numericdata)
k = round(1 + 3.222 * log10(n), digits=0)
M = max(numericdata)
m = min(numericdata)
h = ceiling((M-m)/k)
# 3. Calculate breakpoints and distribute the data
# Note: Adding 'h' to the maximum ensures the highest value is captured in the cuts
breakpoints = seq(from = m, to = M + h, by = h)
classdata = cut(numericdata, breaks = breakpoints)
# 4. Generate the Histogram to visualize system Velocity
hist(numericdata, prob = TRUE, breaks=k, main = "Histogram of TPS Processing Times", xlab="Time (ms)", col="lightblue")