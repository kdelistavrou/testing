# 1. Read the simulated CSV file
data = read.table('C:\\Users\\NYC\\Downloads\\ISBDA_20-5-2026\\omniretail_simulated_data.csv', header = TRUE, sep = ",")
# 2. Calculate the frequency table for Payment_Type
freq <- table(data$Payment_Type)
print(freq)
# 3. Calculate and print relative percentage frequencies
relfreq <- freq / sum(freq)
percfreq = relfreq * 100
percfreqText <- paste0(names(percfreq), ": ", round(percfreq, 2), "%")
print(percfreqText)
# 4. Generate visual outputs for the MIS dashboard
barplot(freq, main="Transactions by Payment Type", col="steelblue", las=1)
pie(freq, main="Payment Type Breakdown")