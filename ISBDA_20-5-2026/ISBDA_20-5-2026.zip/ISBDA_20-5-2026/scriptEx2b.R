# 1. Read your dataset and target the numeric column
listdata = read.table('C:\\Users\\NYC\\Downloads\\ISBDA_20-5-2026\\omniretail_simulated_data.csv', header = TRUE, sep = ",")
numericdata <- unlist(listdata$Processing_Time)
# 2. Automate Sturges' Rule calculations
n = length(numericdata)
k = round(1 + 3.222 * log10(n), digits=0)
M = max(numericdata)
m = min(numericdata)
h = ceiling((M-m)/k)
# 3. Calculate breakpoints and distribute the data
breakpoints = seq(from = m, to = M + h, by = h)
classdata = cut(numericdata, breaks = breakpoints)
# 4. Calculate the density curve FIRST to find its maximum height
dens <- density(numericdata)
max_height <- max(dens$y)
# 5. Generate the Histogram, forcing the y-axis to fit the curve
# We use ylim = c(0, max_height * 1.1) to add a 10% blank buffer at the top
hist(numericdata, prob = TRUE, breaks=k, main = "Histogram of TPS Processing Times",
     xlab="Time (ms)", col="lightblue", ylim=c(0, max_height * 1.1))
# 6. Add the distribution (density) curve overlay
# Since we already calculated 'dens', we can just pass it directly to lines()
lines(dens, col="darkred", lwd=2)