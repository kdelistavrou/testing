# OmniRetail Global: Data Generation Script
# Run this script to create your 2000-record dataset for the workshop
# Set seed for reproducibility
set.seed(123)
# 1. Define the sample size
n <- 2000000
# 2. Generate Qualitative Data: Payment Types
# Simulating a realistic distribution of payment preferences
payment_types <- c("Credit Card", "Digital Wallet", "Debit Card", "Bank Transfer", "Cryptocurrency")
Payment_Type <- sample(payment_types, n, replace = TRUE, prob = c(0.35, 0.30, 0.15, 0.15, 0.05))
# 3. Generate Quantitative Data: Transaction Processing Times (in milliseconds)
# Simulating a legacy system with a right-skewed distribution (mostly fast, some very slow)
Processing_Time <- round(rlnorm(n, meanlog = 4.8, sdlog = 0.5))
# 4. Combine into a dataframe
omni_data <- data.frame(Payment_Type, Processing_Time)
# 5. Export to CSV
write.csv(omni_data, "C:\\Users\\NYC\\Downloads\\ISBDA_20-5-2026\\omniretail_simulated_data.csv", row.names = FALSE)
print("Dataset 'omniretail_simulated_data.csv' generated successfully!")